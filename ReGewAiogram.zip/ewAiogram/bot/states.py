"""FSM States for the Telegram bot"""

from aiogram.fsm.state import State, StatesGroup

class RegistrationStates(StatesGroup):
    """States for account registration process"""
    waiting_for_country = State()
    waiting_for_count = State()
    waiting_for_confirmation = State()
    registering_accounts = State()

class ProxyStates(StatesGroup):
    """States for proxy management"""
    waiting_for_proxy_file = State()

class CountryStates(StatesGroup):
    """States for country management"""
    exporting_countries = State()
