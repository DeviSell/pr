"""Validation utilities"""

import re
import aiohttp
import asyncio
from typing import Tuple, Optional

def validate_proxy_format(proxy_string: str) -> bool:
    """
    Validate proxy format: ip:port:user:password
    
    Args:
        proxy_string: Proxy string to validate
        
    Returns:
        bool: True if format is valid
    """
    pattern = r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5}):([^:]+):(.+)$'
    return bool(re.match(pattern, proxy_string))

def parse_proxy(proxy_string: str) -> Optional[Tuple[str, int, str, str]]:
    """
    Parse proxy string into components
    
    Args:
        proxy_string: Proxy string in format ip:port:user:password
        
    Returns:
        Tuple of (ip, port, username, password) or None if invalid
    """
    if not validate_proxy_format(proxy_string):
        return None
    
    parts = proxy_string.split(':')
    try:
        ip = parts[0]
        port = int(parts[1])
        username = parts[2]
        password = parts[3]
        return (ip, port, username, password)
    except (ValueError, IndexError):
        return None

async def test_proxy_connection(proxy_string: str, timeout: int = 10) -> bool:
    """
    Test proxy connection
    
    Args:
        proxy_string: Proxy string to test
        timeout: Connection timeout in seconds
        
    Returns:
        bool: True if proxy is working
    """
    proxy_data = parse_proxy(proxy_string)
    if not proxy_data:
        return False
    
    ip, port, username, password = proxy_data
    proxy_url = f"http://{username}:{password}@{ip}:{port}"
    
    try:
        # Используем правильный способ работы с прокси в aiohttp
        connector = aiohttp.TCPConnector()
        async with aiohttp.ClientSession(
            connector=connector,
            timeout=aiohttp.ClientTimeout(total=timeout)
        ) as session:
            # Пробуем несколько разных сайтов для проверки
            test_urls = [
                "http://httpbin.org/ip",
                "http://icanhazip.com/"
            ]
            
            for url in test_urls:
                try:
                    async with session.get(
                        url, 
                        proxy=proxy_url,
                        timeout=aiohttp.ClientTimeout(total=timeout)
                    ) as response:
                        if response.status == 200:
                            # Проверяем, что IP изменился (прокси работает)
                            text = await response.text()
                            if ip in text:  # Если наш прокси IP в ответе
                                return True
                except:
                    continue
            
            return False
    except Exception as e:
        # Логируем детали ошибки для отладки
        import logging
        logger = logging.getLogger(__name__)
        logger.debug(f"Proxy test failed for {ip}:{port} - {str(e)}")
        return False

def validate_phone_number(phone: str) -> bool:
    """
    Validate phone number format
    
    Args:
        phone: Phone number to validate
        
    Returns:
        bool: True if format is valid
    """
    # Remove any non-digit characters
    clean_phone = re.sub(r'\D', '', phone)
    
    # Check if it's a valid length (7-15 digits)
    return 7 <= len(clean_phone) <= 15

def validate_country_id(country_id: str) -> bool:
    """
    Validate country ID format
    
    Args:
        country_id: Country ID to validate
        
    Returns:
        bool: True if format is valid
    """
    return country_id.isdigit() and len(country_id) <= 4
